window.__require = function e(t, n, o) {
function a(i, s) {
if (!n[i]) {
if (!t[i]) {
var r = i.split("/");
r = r[r.length - 1];
if (!t[r]) {
var l = "function" == typeof __require && __require;
if (!s && l) return l(r, !0);
if (c) return c(r, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = r;
}
var u = n[i] = {
exports: {}
};
t[i][0].call(u.exports, function(e) {
return a(t[i][1][e] || e);
}, u, u.exports, e, t, n, o);
}
return n[i].exports;
}
for (var c = "function" == typeof __require && __require, i = 0; i < o.length; i++) a(o[i]);
return a;
}({
AnimationCtr: [ function(e, t) {
"use strict";
cc._RF.push(t, "67753jaJBBMHLSzPfXSQEp2", "AnimationCtr");
cc.Class({
extends: cc.Component,
properties: {
animation: cc.Animation
},
onEnable: function() {
this.animation.on("finished", this.onFinished, this);
},
onDisable: function() {
this.animation.off("finished", this.onFinished, this);
},
onFinished: function() {
"cocos_icon" === this.animation.node.name && cc.find("Canvas/game_log").getComponent(cc.Animation).play();
if ("game_log" === this.animation.node.name) {
var e = cc.find("Canvas/res_load_progressBar");
cc.WXHelper.downloadAllResources(e, function(e, t) {
var n = cc.fadeIn(.5);
e.runAction(n);
e.getComponent(cc.ProgressBar).progress = t;
if (100 === t) {
e.destroy();
cc.WXHelper.iswxPlatform() && cc.WXHelper._login(function() {
cc.WXHelper._getUserInfo(function() {
cc.director.loadScene("hall");
});
});
}
});
}
"test" === this.animation.node.name && console.log("test");
}
});
cc._RF.pop();
}, {} ],
AppStart: [ function(e, t) {
"use strict";
cc._RF.push(t, "650e2fZGGBOmr1iPumlwK4b", "AppStart");
cc.Class({
extends: cc.Component,
editor: {
executeInEditMode: !0
},
properties: {
gameVersion: {
default: null,
type: cc.Label
},
gameAutor: {
default: null,
type: cc.Label
},
cocosVersion: {
default: null,
type: cc.Label
}
},
update: function() {},
start: function() {},
onEnable: function() {},
onLoadResEvent: function() {},
init: function() {},
onWxMixGameLoadingEvent: function() {}
});
cc._RF.pop();
}, {} ],
AudioMgr: [ function(e, t) {
"use strict";
cc._RF.push(t, "468474JWMhI67G6Vfzu6xbU", "AudioMgr");
var n = {
bgmVolume: .8,
sfxVolume: .8,
bgmswitch: 1,
sfxswitch: 1,
bgmAudioID: -1,
sfxAudioID: -1,
bgm_v: 0,
sfx_v: 0,
init: function() {
var e = cc.vv.localData.setting;
this.bgmVolume = e.sound_volum;
this.sfxVolume = e.sfx_volum;
this.bgmswitch = e.sound_switch;
this.sfxswitch = e.sfx_switch;
console.log(e.sound_volum);
console.log(e.sound_switch + "音量开关");
console.log(e.sfx_volum);
console.log(e.sfx_switch + "音效开关");
},
getUrl: function(e) {
return cc.url.raw("resources/audio/" + e);
},
playBGM: function() {
if (0 != cc.vv.localData.setting.sound_switch && -1 == this.bgmAudioID) {
var e = this.getUrl("background.mp3");
this.bgmAudioID = cc.audioEngine.play(e, !0, cc.vv.localData.setting.sound_volum);
}
},
playEffect: function(e) {
1 == cc.vv.localData.setting.sfx_switch && null != e && (this.sfxAudioID = cc.audioEngine.play(cc.url.raw(e), !1, this.sfxVolume));
},
setSFXVolume: function(e, t) {
if (this.sfxVolume != e || t) {
this.sfxVolume = e;
cc.audioEngine.setVolume(this.sfxAudioID, e);
}
},
setBGMVolume: function(e, t) {
if (this.bgmVolume != e || t) {
this.bgmVolume = e;
cc.audioEngine.setVolume(this.bgmAudioID, e);
}
},
playClickedBgm: function() {
1 != cc.vv.localData.setting.sfx_switch || this.playEffect("resources/audio/button_click.mp3");
},
getBGMState: function() {
return cc.audioEngine.getState(this.bgmAudioID);
},
stopBGM: function() {
if (-1 != this.bgmAudioID) {
cc.audioEngine.stop(this.bgmAudioID);
this.bgmAudioID = -1;
}
}
};
t.exports = n;
cc._RF.pop();
}, {} ],
ColliderListener: [ function(e, t) {
"use strict";
cc._RF.push(t, "99741zHCzREprH/syFX4vpW", "ColliderListener");
cc.Class({
extends: cc.Component,
editor: {
menu: "自定义组件/碰撞组件/碰撞监听",
requireComponent: cc.BoxCollider,
disallowMultiple: !0
},
properties: {},
onLoad: function() {
cc.director.getCollisionManager().enabled = !0;
},
onCollisionEnter: function() {
"prop" == this.node.group && this.node.destroy();
"wall" == this.node.group && this.node.destroy();
"gasoline" == this.node.group && this.node.destroy();
"enemy" == this.node.group && this.node.destroy();
"cartridge" == this.node.group && this.node.destroy();
},
onCollisionStay: function() {},
onCollisionExit: function() {}
});
cc._RF.pop();
}, {} ],
CountDown: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "d8dad2/z7tM6Kl1liJyoJW8", "CountDown");
var o, a = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
o(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), c = this && this.__decorate || function(e, t, n, o) {
var a, c = arguments.length, i = c < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var s = e.length - 1; s >= 0; s--) (a = e[s]) && (i = (c < 3 ? a(i) : c > 3 ? a(t, n, i) : a(t, n)) || i);
return c > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var i = cc._decorator, s = i.ccclass, r = (i.property, function(e) {
a(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t._nextTime = 0;
return t;
}
t.prototype.start = function() {
var e = this;
setInterval(function() {
0 !== e._nextTime && (e.node.getComponent(cc.Label).string = cc.Utils.formatDuring(e._nextTime));
}, 1e3);
};
t.prototype.update = function() {};
return c([ s ], t);
}(cc.Component));
n.default = r;
cc._RF.pop();
}, {} ],
DLocal: [ function(e, t) {
"use strict";
cc._RF.push(t, "732cbdleihHvbxN92Jqjwph", "DLocal");
cc.Class({
extends: cc.Component,
properties: {
option: null,
setting: null
},
init: function() {
this.option = {
optionsum: 4,
jushu: 4,
jifen: 6,
renshu: 9,
fangfei: 14,
qingyise: 1,
jinlong: 0,
jinkan: 0,
duiduihu: 0,
roomPrice: 2
};
this.setting = {
sound_volum: 1,
sfx_volum: 1,
sound_switch: 1,
sfx_switch: 1,
lan_type: 1,
lan_sex: 0,
no_warning_match_id: 0
};
this.loadOption();
this.loadSetting();
},
loadOption: function() {
if (cc.vv.wxHelper.iswxPlatform()) {
console.log("In Weixin");
var e = wx.getStorageSync("option");
console.log(typeof e);
"string" != typeof e && (this.option = e);
} else {
var t = JSON.parse(cc.sys.localStorage.getItem("option"));
if (null != t) for (var n in t) this.option[n] = t[n];
}
},
loadSetting: function() {
if (cc.vv.wxHelper.iswxPlatform()) {
var e = wx.getStorageSync("setting");
console.log(typeof e);
"string" != typeof e && (this.setting = e);
} else {
var t = JSON.parse(cc.sys.localStorage.getItem("setting"));
if (null != t) for (var n in t) this.setting[n] = t[n];
}
},
saveOption: function() {
cc.vv.wxHelper.iswxPlatform() ? wx.setStorageSync("option", this.option) : cc.sys.localStorage.setItem("option", JSON.stringify(this.option));
},
saveSetting: function() {
cc.vv.wxHelper.iswxPlatform() ? wx.setStorageSync("setting", this.setting) : cc.sys.localStorage.setItem("setting", JSON.stringify(this.setting));
}
});
cc._RF.pop();
}, {} ],
DUser: [ function(e, t) {
"use strict";
cc._RF.push(t, "74021n2svlCUKB5N3rrCbn/", "DUser");
var n = {
userName: null,
avatarUrl: null,
bestRecord: null,
currentRecord: null,
gameStatus: null
};
t.exports = n;
cc.DataUser = n;
cc._RF.pop();
}, {} ],
GameConfig: [ function(e, t) {
"use strict";
cc._RF.push(t, "eeef78QfL9EYbCgxkWAEWCu", "GameConfig");
var n = {
gameName: "CollideBrick",
gameAutor: "zhefeng.zhang",
gameVersion: "1.0.0",
designHeight: 1920,
designWidth: 1080,
fitHeight: !1,
fitWidth: !0,
CocosCreatorVersion: "2.0.9",
ip: "websocket.windgzs.cn",
wxUserInfo: [],
getUserInfoBtn: null,
isClickCd: !1,
iType: 0,
iDiff: 0,
tScore: [],
tName: [],
tPlaybackData: null,
sName: "",
msgBox: null,
iWorldLv: 0,
REGISTER: "register",
LOGIN: "login",
GET_SCORE: "getScore",
GET_STEP: "getStep",
GET_RANK: "getRank",
SET_STEP: "setStep",
WXLOGIN: "wxLogin",
GET_WORLD_STEP: "getWorldStep"
};
t.exports = n;
cc.GameConfig = n;
cc._RF.pop();
}, {} ],
GameConst: [ function(e, t) {
"use strict";
cc._RF.push(t, "24707eYnwRCCILM3Cb/z08V", "GameConst");
var n = {
VERSION_STRING: "v1.0.37",
DELAY_CLICK_ENABLE_TIME: 2e3,
DEFAULT_HEAD_AVATAR_FRAME_NAME: "default_head",
URL_RES_INCLUDE_FILE: [ "prefabs", "texture" ],
URL_RES_INCLUDE_SPRITE_ATLAS: [ "buttons", "texts" ],
INDEX_TO_POINT: [ [ -220, 381 ], [ -110, 381 ], [ 0, 381 ], [ 110, 381 ], [ 220, 381 ], [ -275, 286 ], [ -165, 286 ], [ -55, 286 ], [ 55, 286 ], [ 165, 286 ], [ 275, 286 ], [ -330, 191 ], [ -220, 191 ], [ -110, 191 ], [ 0, 191 ], [ 110, 191 ], [ 220, 191 ], [ 330, 191 ], [ -385, 95 ], [ -275, 95 ], [ -165, 95 ], [ -55, 95 ], [ 55, 95 ], [ 165, 95 ], [ 275, 95 ], [ 385, 95 ], [ -440, 0 ], [ -330, 0 ], [ -220, 0 ], [ -110, 0 ], [ 0, 0 ], [ 110, 0 ], [ 220, 0 ], [ 330, 0 ], [ 440, 0 ], [ -385, -95 ], [ -275, -95 ], [ -165, -95 ], [ -55, -95 ], [ 55, -95 ], [ 165, -95 ], [ 275, -95 ], [ 385, -95 ], [ -330, -191 ], [ -220, -191 ], [ -110, -191 ], [ 0, -191 ], [ 110, -191 ], [ 220, -191 ], [ 330, -191 ], [ -275, -286 ], [ -165, -286 ], [ -55, -286 ], [ 55, -286 ], [ 165, -286 ], [ 275, -286 ], [ -220, -381 ], [ -110, -381 ], [ 0, -381 ], [ 110, -381 ], [ 220, -381 ] ],
WX_SCENE_VALUE_1007: "1007",
WX_SCENE_VALUE_1008: "1008",
WX_SCENE_VALUE_1022: "1022",
WX_SCENE_VALUE_1044: "1044",
WX_SCENE_VALUE_1104: "1104",
SUBSTRING_LENGTH: 6,
SUBSTRING_MAXLENGTH: 10,
MESSAGE_SUBSTRING_MAXLENGTH: 88,
MESSAGE_SUBSTRING_LENGTH: 76,
SENDMORETIMES: 1,
HOLDNUM_LEN: 2,
BG_TEXTURE_NAME: [ null, "", "" ],
COLOR_TYPE: {
TYPE_0: {
r: 255,
g: 255,
b: 255,
a: 255
},
TYPE_1: {
r: 72,
g: 115,
b: 87,
a: 255
},
TYPE_2: {
r: 147,
g: 136,
b: 106,
a: 255
},
TYPE_3: {
r: 255,
g: 215,
b: 0,
a: 255
},
TYPE_4: {
r: 255,
g: 255,
b: 141,
a: 255
},
TYPE_5: {
r: 162,
g: 95,
b: 24,
a: 255
},
TYPE_6: {
r: 228,
g: 225,
b: 169,
a: 255
},
TYPE_7: {
r: 206,
g: 155,
b: 98,
a: 255
},
TYPE_8: {
r: 163,
g: 151,
b: 104,
a: 255
},
TYPE_9: {
r: 88,
g: 200,
b: 100,
a: 255
},
TYPE_10: {
r: 218,
g: 114,
b: 27,
a: 255
},
TYPE_11: {
r: 158,
g: 99,
b: 31,
a: 255
},
TYPE_12: {
r: 148,
g: 137,
b: 137,
a: 255
},
TYPE_13: {
r: 240,
g: 240,
b: 50,
a: 255
},
TYPE_14: {
r: 182,
g: 64,
b: 22,
a: 255
},
TYPE_15: {
r: 240,
g: 60,
b: 45,
a: 255
},
TYPE_16: {
r: 204,
g: 138,
b: 85,
a: 255
},
get: function(e) {
return "undefined" != typeof this["TYPE_" + e] ? new cc.Color(this["TYPE_" + e]) : new cc.Color(this.TYPE_0);
}
}
};
t.exports = n;
cc.GameConst = n;
cc._RF.pop();
}, {} ],
GameEnum: [ function(e, t) {
"use strict";
cc._RF.push(t, "b94aedxHBxBr4rdj8pimPXf", "GameEnum");
cc._RF.pop();
}, {} ],
GameErrorCode: [ function(e, t) {
"use strict";
cc._RF.push(t, "e77d6UxKP5KSp7cUzj+99CF", "GameErrorCode");
var n = cc.Enum({
ERR_ROOM_NOT_FOUND: 101,
ERR_ROOM_FULL: 102,
ERR_ROOM_EXIST: 103,
ERR_ROOM_MONEY_LACK: 104
});
t.exports = {
ErrCodeEnterRoom: n
};
cc._RF.pop();
}, {} ],
GameEvent: [ function(e, t) {
"use strict";
cc._RF.push(t, "ebbb1FA14JDHrvKF1yrPhTm", "GameEvent");
var n = {
EVENT_WSS_OPEN: "wss_open",
EVENT_WSS_CLOSED: "wss_closed",
EVENT_WX_LOGIN_STATE: "wx_login_state",
EVENT_WX_QUERY: "wx_query",
EVENT_ENTER_FOREGROUND: "enter_foreground",
EVENT_ENTER_BACKGROUND: "enter_background",
EVENT_AUDIO_INTERRUPTION_BEGIN: "EVENT_AUDIO_INTERRUPTION_BEGIN",
EVENT_AUDIO_INTERRUPTION_END: "EVENT_AUDIO_INTERRUPTION_END",
EVENT_HALL_PREPARE: "hall_prepared",
EVENT_NEW_MESSAGE: "",
EVENT_MESSAGE_READED: "message_readed",
EVENT_MEMBER_CHANGE: "member_change",
EVENT_GAME_BEGIN: "game_begin",
EVENT_GAME_SETTLEMENT: "game_settlement",
EVENT_GAME_OVER: "game_over",
EVENT_ROOM_CLOSED: "room_closed",
EVENT_ROOM_VOTE_DISBAND: "room_vote_disband",
EVENT_GAME_DISBAND_SETTLEMENT: "game_disband_settlement",
EVENT_AUTOMATIC_CHANGED: "automatic_changed",
EVENT_INTERACTIVE: "interactive_play",
EVENT_MJ_NEWCMD: "newcmd",
EVENT_MJ_CMDRESPOND: "cmdrespond",
EVENT_MJ_MOPAI: "mopai",
EVENT_MJ_BUHUA: "buhua",
EVENT_MJ_CHI: "chi",
EVENT_MJ_PENG: "peng",
EVENT_MJ_GANG: "gang",
EVENT_MJ_ANGANG: "angang",
EVENT_MJ_JIAGANG: "jiagang",
EVENT_MJ_DA: "da",
EVENT_MJ_TING: "ting",
EVENT_MJ_KAIJIN: "kaijin",
EVENT_MJ_GOLDCAMP: "goldCamp",
EVENT_MJ_MOON: "moon",
EVENT_SETTING_TING: "setting_ting",
EVENT_MATCH_STATE_CHANGED: "match_state_changed",
EVENT_MATCH_ENTER_HALL: "match_back_hall",
EVENT_MATCH_COMPLETED_RESULT_SHOW: "match_completed_result_show",
EVENT_MATCH_AWARD_SHARE: "match_award_share",
EVENT_MATCH_MATCHING_SHOW: "match_matching_show",
EVENT_BREAK_SHARE: "answer_break_share",
EVENT_BACK_HALL: "answer_back_hall",
EVENT_START_TIME: "answer_start_time",
EVENT_UPDATE_HEART: "answer_update_heart",
EVENT_INIT_MAPDATA_COMPLETE: "init_mapdata_complete",
EVENT_GAME_RESTART: "game_restart",
EVENT_GAME_WIN: "game_win",
handlers: null,
init: function() {
this.handlers = {};
},
dispatchEvent: function(e, t) {
if (this.handlers[e]) {
console.log("HANDLER " + e);
for (var n in this.handlers[e]) this.handlers[e][n](t);
} else console.log("NO HANDLER " + e);
},
addEventHandler: function(e, t, n) {
this.handlers[e] || (this.handlers[e] = {});
this.handlers[e][n.__instanceId] = function(e) {
t(e);
};
},
removeEventHandler: function(e, t) {
console.log("removeEvent: " + e + " targetId: " + t.__instanceId);
this.handlers[e] && this.handlers[e][t.__instanceId] && delete this.handlers[e][t.__instanceId];
},
dumpEventHandlers: function() {
console.log("dumpEventHandlers begin");
for (var e in this.handlers) {
console.log("--" + e);
for (var t in this.handlers[e]) console.log("  --" + typeof t + " " + typeof this.handlers[e][t.__instanceId]);
}
console.log("dumpEventHandlers end");
}
};
t.exports = n;
cc.GameEvent = n;
cc._RF.pop();
}, {} ],
GameLanguage: [ function(e, t) {
"use strict";
cc._RF.push(t, "2efe2v60JhJyJSnejSOfrEB", "GameLanguage");
var n = {
zhLanguage: [ "游戏版本:", "游戏作者:", "你赢了", "你输了", "暂停", "{0}:{1}:{2}", "挑战超时", "暂无成功记录" ],
enLanguage: [ "gameVersion:", "gameAutor", "You Win", "You Lose", "pause", "{0}:{1}", "challengeTimeout", "noRecordOfSuccess" ]
};
t.exports = n;
cc.GameLanguage = n;
cc._RF.pop();
}, {} ],
GameNetMgr: [ function(e, t) {
"use strict";
cc._RF.push(t, "8ee42q8q5RCO5Xlaun93hyM", "GameNetMgr");
cc.Class({
extends: cc.Component,
properties: {
dataEventHandler: null,
roomData: null,
matchData: null,
reconnectAnims: null
},
dispatchEvent: function(e, t) {
this.dataEventHandler && this.dataEventHandler.emit(e, t);
},
init: function() {
this.roomData = new DRoom();
this.matchData = new DMatch();
this.initEventHandlers();
},
initEventHandlers: function() {
var e = this;
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_WSS_OPEN, function() {
e.tryReconnectLogicServer();
}, this);
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_WSS_CLOSED, function() {}, this);
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_ENTER_FOREGROUND, function() {
cc.vv.audioMgr.playBGM();
cc.vv.socketMgr.checkNetState();
}, this);
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_ENTER_BACKGROUND, function() {
cc.vv.audioMgr.stopBGM();
}, this);
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_AUDIO_INTERRUPTION_BEGIN, function() {
cc.vv.audioMgr.stopBGM();
}, this);
cc.vv.gameEvent.addEventHandler(cc.vv.gameEvent.EVENT_AUDIO_INTERRUPTION_END, function() {
cc.vv.audioMgr.playBGM();
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_104", function(e) {
if (0 == e.resultCode) if (null != cc.vv.wxHelper._queryData) {
if ("undefined" != typeof (e = cc.vv.wxHelper._queryData) && "undefined" != typeof e.inviterId && "undefined" != typeof e.inviterName) {
var t = parseInt(e.inviterId), n = e.inviterName, o = e.inviterMatchId, a = new PacketWriter();
a.writeid(cc.vv.packid.PACKETID_210);
a.writeu8(t);
a.writes(n);
"undefined" != typeof o ? a.writeu4(o) : a.writeu4(0);
cc.vv.socketMgr.bufferPack(a.getdata());
}
} else console.log("[ queryData is Null ]");
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_230", function(e) {
cc.vv.lan.FZMJ_NOTIVE = e.noticeContent;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_240", function(e) {
console.log("[ => callback 240 ]");
console.log(e.language);
if (e.language.length > 0 && "[" == e.language.substr(0, 1)) console.log("start with ["); else {
var t = JSON.parse(e.language);
console.log(t);
console.log(typeof t);
for (var n in t) {
var o = t[n], a = n.length, c = n.lastIndexOf(".");
console.log("idx " + c);
if (-1 != c) {
var i = n.substring(0, c), s = n.substring(c + 1, a);
console.log("front = " + i);
console.log(" back = " + s);
cc.vv.lan[i][parseInt(s)] = o;
} else cc.vv.lan[n] = o;
}
}
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_246", function(e) {
console.log("[ => callback 246 ]");
console.log(e);
if ("" != e.const) {
var t = JSON.parse(e.const);
console.log(t);
console.log(typeof t);
for (var n in t) {
var o = t[n], a = n.length, c = n.lastIndexOf(".");
console.log("idx " + c);
if (-1 != c) {
var i = n.substring(0, c), s = n.substring(c + 1, a);
console.log("front = " + i);
console.log(" back = " + s);
cc.vv.const[i][parseInt(s - 1)] = Number(o);
} else cc.vv.const[n] = o;
}
} else console.log("  246  Object  is  null");
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_249", function(e) {
console.log("[ => callback 249 ]");
console.log(e);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_303", function(t) {
0 == t.resultCode ? cc.vv.gameNetMgr.roomData.seatIndex != cc.vv.gameNetMgr.roomData.zhuangIndex && e.dispatchEvent(cc.vv.gameEvent.EVENT_ROOM_CLOSED) : console.log("_PACKET_303 respond. code = " + t.resultCode);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_309", function(t) {
e.roomData.readPacket309(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_ROOM_VOTE_DISBAND);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_310", function(t) {
e.roomData.readPacket310(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_GAME_DISBAND_SETTLEMENT);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_311", function() {
e.roomData.gameBegin ? e.dispatchEvent(cc.vv.gameEvent.EVENT_ROOM_CLOSED) : e.roomData.zhuangIndex == e.roomData.seatIndex ? cc.vv.utils.showDialogOK(cc.vv.lan.FZMJ_LAN[38], function() {
cc.vv.gameNetMgr.roomData.clean();
cc.vv.gameNetMgr.dispatchEvent(cc.vv.gameEvent.EVENT_ROOM_CLOSED);
}) : e.dispatchEvent(cc.vv.gameEvent.EVENT_ROOM_CLOSED);
e.roomData.gameBegin = !0;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_315", function() {}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_317", function() {}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_318", function(t) {
e.dispatchEvent(cc.vv.gameEvent.EVENT_INTERACTIVE, t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_401", function(t) {
e.roomData.readPacket401(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_GAME_BEGIN);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_402", function(t) {
e.roomData.readPacket402(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_NEWCMD, t.pindex);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_403", function(t) {
e.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_CMDRESPOND, t.resultCode);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_404", function(t) {
var n = 0;
255 != t.type && 255 != t.value && (n = cc.vv.const.MJTYPE_MULTI * t.type + t.value);
e.doMOPAI(t.direction, n);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_405", function(t) {
e.doOptResult(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_406", function() {}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_407", function(t) {
e.roomData.readPacket407(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_GAME_SETTLEMENT);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_410", function(t) {
e.roomData.readPacket410(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_MEMBER_CHANGE);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_411", function(t) {
e.doKAIJIN(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_413", function(t) {
e.roomData.readPacket413(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_MOON);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_434", function(t) {
console.log(t);
e.roomData.readPacket434(t);
e.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_GOLDCAMP, t.direction);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_909", function(t) {
if (t.playerId == cc.vv.myself.playerId) {
t.autoState > 0 ? cc.vv.roomData.bAutomatic = !0 : cc.vv.roomData.bAutomatic = !1;
e.dispatchEvent(cc.vv.gameEvent.EVENT_AUTOMATIC_CHANGED);
}
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_951", function(t) {
console.log(t);
e.matchData.readPacket951(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_953", function(t) {
console.log(t);
e.matchData.readPacket953(t);
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_MATCH_STATE_CHANGED, t.state);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_956", function(t) {
console.log(t);
e.matchData.readPacket956(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_957", function(e) {
console.log(e);
0 != e.resultCode && cc.vv.utils.showDialogOK("continues. errcode=" + e.resultCode, null, !1);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_958", function(t) {
console.log(t);
e.matchData.readPacket958(t);
cc.vv.matchData.gamePrepareShareArr = [];
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_959", function(t) {
console.log(t);
e.matchData.readPacket959(t);
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_MATCH_AWARD_SHARE);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_961", function(e) {
console.log(" => PACKET_961");
console.log(e);
cc.vv.matchData.gamePrepareShareArr.push(e);
cc.vv.matchData.curScore += e.fuelValue;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_965", function(e) {
console.log("=> PACKET_965");
console.log(e);
cc.vv.matchData.gamePrepareShareArr = e.gamePrepareShareLen_child;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1001", function(e) {
cc.vv.myself.largessGoldValue = e.gold;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1003", function(e) {
console.log("=> PACKET_1003");
console.log(e);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1004", function(e) {
console.log("=> PACKET_1004");
console.log(e);
cc.vv.matchData.goldFieldId = e.goldGameID;
cc.vv.matchData.goldFieldState = e.state;
0 == cc.vv.matchData.goldPlayerEnterId && (cc.vv.matchData.goldPlayerEnterId = cc.vv.matchData.goldFieldId);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1007", function(t) {
console.log("=> PACKET_1007");
console.log(t);
e.roomData.readPacket1007(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1005", function(e) {
console.log("=> PACKET_1005");
console.log(e);
for (var t = 0; t < e.goldGameNum_child.length; t++) {
var n = e.goldGameNum_child[t].goldGameID, o = e.goldGameNum_child[t].playerNum;
cc.vv.matchData.goldFieldOnlines[n - 1] = o;
}
console.log(cc.vv.matchData.goldFieldOnlines);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1010", function(t) {
console.log("=> PACKET_1010");
console.log(t);
e.roomData.readPacket1010(t);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1011", function() {}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1016", function() {
cc.vv.myself.redPacketTag = !0;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1017", function(e) {
console.log("=> gameEvent callBack 1017");
0 == e.resultCode && cc.vv.utils.showDialogOK(cc.vv.lan.MATCH_LAN[127].format(e.ticketAward), function() {
this.node.destroy();
}, !1, cc.vv.enum.EnumLabelHorizontalAlign.CENTER);
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1020", function(e) {
console.log("=> gameEvent callBack 1020");
console.log(e);
for (var t = 0; t < e.goldMatchInfoLen; t++) {
var n = e.goldMatchInfoLen_child[t];
cc.vv.matchData.goldMatchPacketValueArr.push(n.awardBonus / 100);
n.goldMatchType == cc.vv.enum.EnumGoldGameType.EGGT_LOW ? cc.vv.myself.sprogGoldMatchTimes = n.playedTimes : n.goldMatchType == cc.vv.enum.EnumGoldGameType.EGGT_MIDDLE ? cc.vv.myself.richGoldMatchTimes = n.playedTimes : n.goldMatchType == cc.vv.enum.EnumGoldGameType.EGGT_HIGHT && (cc.vv.myself.masterGoldMatchTimes = n.playedTimes);
}
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1021", function(e) {
console.log("=> PACKET_1021");
console.log(e);
cc.vv.myself.isFreeGold = !0;
}, this);
cc.vv.gameEvent.addEventHandler("_PACKET_1022", function(e) {
console.log("=> PACKET_1022");
cc.vv.matchData.goldMangerArr = [];
cc.vv.const.GOLD_RISING_POURING = [];
cc.vv.const.GOLD_ENTER_CONDITION = [];
cc.vv.matchData.goldMatchOpenIDArr = [];
cc.vv.matchData.goldMangerArr = e.goldMatchLen_child;
var t = cc.vv.matchData.goldMangerArr;
console.log(t);
for (var n = 0; n < e.goldMatchLen; n++) {
cc.vv.const.GOLD_RISING_POURING.push(t[n].castBottom);
cc.vv.const.GOLD_ENTER_CONDITION.push({
min: t[n].lowerLimit,
max: t[n].superiorLimit
});
e.goldMatchLen_child[n].isOpen > 0 && cc.vv.matchData.goldMatchOpenIDArr.push(t[n].goldMatchType);
}
}, this);
},
doOptResult: function(e) {
var t = cc.vv.const.MJTYPE_MULTI;
console.log("receive opt, seat: " + e.direction + " opt:" + cc.vv.lan.MJOPT_NAME[e.option]);
console.log(e);
var n = e.option, o = t * e.pai1_type + e.pai1_value, a = t * e.pai2_type + e.pai2_value, c = t * e.pai3_type + e.pai3_value;
if (n == cc.vv.enum.EnumCmdType.MJOPT_BUHUA) {
for (var i = [], s = [], r = e.z_isFirstBuhua, l = e.optionHua_child[0], u = 0; u < l.huaCard_Num_child.length; u++) i.push(t * l.huaCard_Num_child[u].huaCard_type + l.huaCard_Num_child[u].huaCard_value);
for (u = 0; u < l.putCard_Num_child.length; u++) s.push(t * l.putCard_Num_child[u].putCard_type + l.putCard_Num_child[u].putCard_value);
this.doBUHUA(e.direction, i, s, r);
} else if (n == cc.vv.enum.EnumCmdType.MJOPT_CHI) this.doCHI(e.direction, o, a, c); else if (n == cc.vv.enum.EnumCmdType.MJOPT_PENG) this.doPENG(e.direction, o); else if (n == cc.vv.enum.EnumCmdType.MJOPT_GANG) this.doGANG(e.direction, o); else if (n == cc.vv.enum.EnumCmdType.MJOPT_ANGANG) this.doANGANG(e.direction, o); else if (n == cc.vv.enum.EnumCmdType.MJOPT_JIAGANG) this.doJIAGANG(e.direction, o); else if (n == cc.vv.enum.EnumCmdType.MJOPT_DA) {
this.roomData.lastDAIndex = e.direction;
this.doDA(e.direction, o);
} else if (n == cc.vv.enum.EnumCmdType.MJOPT_GUO1) {
this.roomData.lastDAIndex = e.direction;
this.doDA(e.direction, o);
} else if (n == cc.vv.enum.EnumCmdType.MJOPT_DA_T) {
this.roomData.lastDAIndex = e.direction;
this.doDA(e.direction, o);
} else if (n == cc.vv.enum.EnumCmdType.MJOPT_GUO2) {
this.roomData.lastDAIndex = e.direction;
this.doDA(e.direction, o);
} else if (n == cc.vv.enum.EnumCmdType.MJOPT_TING) {
this.roomData.lastDAIndex = e.direction;
this.doTING(e.direction, o);
}
},
doKAIJIN: function(e) {
var t = cc.vv.const.MJTYPE_MULTI, n = t * e.goldType + e.goldValue;
this.roomData.king = n;
for (var o = this.roomData.zhuangIndex, a = this.roomData.seats[o], c = 0; c < e.flowerNum_child.length; c++) {
var i = t * e.flowerNum_child[c].type + e.flowerNum_child[c].value;
a.huas.push(i);
}
var s = this.roomData.remainCard;
this.roomData.subRemainCard(e.flowerNum_child.length + 1);
var r = this.roomData.remainCard;
console.log("kaijin bupai len=" + e.flowerNum_child.length + 1);
console.log("sub remain card x" + (e.flowerNum_child.length + 1) + " old=" + s + " new=" + r + " opt=kaiju buhua");
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_KAIJIN, {
seatIndex: o,
king: n,
huacount: e.flowerNum_child.length
});
},
doBUHUA: function(e, t, n, o) {
for (var a = this.roomData.seatIndex, c = this.roomData.seats[e], i = 0; i < t.length; i++) {
if (e == a) {
var s = c.holds.indexOf(t[i]);
-1 != s && c.holds.splice(s, 1);
}
c.huas.push(t[i]);
}
if (e == a) for (i = 0; i < n.length; i++) c.holds.push(n[i]);
var r = this.roomData.remainCard;
this.roomData.subRemainCard(t.length);
var l = this.roomData.remainCard;
console.log("bupai len=" + t.length);
console.log("sub remain card x" + t.length + " old=" + r + " new=" + l + " opt=buhua");
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_BUHUA, {
seatIndex: e,
huas: t,
bupais: n,
kaiju: o
});
},
doCHI: function(e, t, n, o) {
var a = this.roomData.seatIndex, c = this.roomData.seats[e];
if (e == a) {
var i = -1;
-1 != (i = c.holds.indexOf(t)) && c.holds.splice(i, 1);
-1 != (i = c.holds.indexOf(o)) && c.holds.splice(i, 1);
} else {
c.holds.splice(0, 1);
c.holds.splice(0, 1);
}
c.chis.push(t);
c.chis.push(n);
c.chis.push(o);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_CHI, {
seatIndex: e,
pai1: t,
pai2: n,
pai3: o
});
},
doPENG: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) for (var a = 0; a < 2; a++) {
var c = o.holds.indexOf(t);
-1 != c && o.holds.splice(c, 1);
} else {
o.holds.splice(0, 1);
o.holds.splice(0, 1);
}
o.pengs.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_PENG, {
seatIndex: e,
pai: t
});
},
doGANG: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) for (var a = 0; a < 3; a++) {
var c = o.holds.indexOf(t);
-1 != c && o.holds.splice(c, 1);
} else {
o.holds.splice(0, 1);
o.holds.splice(0, 1);
o.holds.splice(0, 1);
}
o.gangs.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_GANG, {
seatIndex: e,
pai: t
});
},
doANGANG: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) for (var a = 0; a < 4; a++) {
var c = o.holds.indexOf(t);
-1 != c && o.holds.splice(c, 1);
} else for (a = 0; a < 4; a++) o.holds.splice(0, 1);
o.angangs.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_ANGANG, {
seatIndex: e,
pai: t
});
},
doJIAGANG: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) for (var a = 0; a < 1; a++) {
var c = o.holds.indexOf(t);
-1 != c && o.holds.splice(c, 1);
} else o.holds.splice(0, 1);
var i = o.pengs.indexOf(t);
-1 != i && o.pengs.splice(i, 1);
o.gangs.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_JIAGANG, {
seatIndex: e,
pai: t
});
},
doDA: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) {
var a = o.holds.indexOf(t);
-1 != a && o.holds.splice(a, 1);
} else o.holds.splice(0, 1);
o.folds.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_DA, {
seatIndex: e,
pai: t
});
},
doTING: function(e, t) {
console.log("[GameNetMgr.doTING] seatIndex=" + e + " pai=" + t);
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
if (e == n) {
var a = o.holds.indexOf(t);
-1 != a && o.holds.splice(a, 1);
} else o.holds.splice(0, 1);
o.folds.push(t);
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_TING, {
seatIndex: e,
pai: t
});
},
doMOPAI: function(e, t) {
var n = this.roomData.seatIndex, o = this.roomData.seats[e];
e == n ? o.holds.push(t) : o.holds.push(0);
var a = this.roomData.remainCard;
this.roomData.subRemainCard(1);
var c = this.roomData.remainCard;
console.log("sub remain card x1 old=" + a + " new=" + c + " opt=mopai");
this.dispatchEvent(cc.vv.gameEvent.EVENT_MJ_MOPAI, {
seatIndex: e,
pai: t
});
},
sendPlayerCmdExcute: function(e, t, n, o, a, c) {
var i = 255, s = 255, r = 255, l = 255;
if (n) {
i = Math.floor(n / cc.vv.const.MJTYPE_MULTI);
s = n % cc.vv.const.MJTYPE_MULTI;
}
if (o) {
r = Math.floor(n / cc.vv.const.MJTYPE_MULTI);
l = n % cc.vv.const.MJTYPE_MULTI;
}
null == a && (a = 0);
c = null == c || 0 == c ? 0 : 1;
var u = new PacketWriter();
u.writeid(cc.vv.packid.PACKETID_403);
u.writeu1(e);
u.writeu1(t);
u.writeu1(i);
u.writeu1(s);
u.writeu1(r);
u.writeu1(l);
u.writeu1(a);
u.writeu1(c);
cc.vv.socketMgr.bufferPack(u.getdata());
},
connectGameServer: function(e) {
this.dissoveData = null;
cc.vv.net.ip = e.ip + ":" + e.port;
console.log(cc.vv.net.ip);
cc.vv.wc.show("正在进入房间");
cc.vv.net.connect(function() {
console.log("onConnectOK");
var t = {
token: e.token,
roomid: e.roomid,
time: e.time,
sign: e.sign
};
cc.vv.net.send("login", t);
}, function() {
console.log("failed.");
cc.vv.wc.hide();
});
},
sendVoteDisband: function(e) {
var t = new PacketWriter();
t.writeid(cc.vv.packid.PACKETID_305);
t.writeu1(e);
cc.vv.socketMgr.bufferPack(t.getdata());
},
sendDisband: function() {
var e = new PacketWriter();
e.writeid(cc.vv.packid.PACKETID_304);
e.writeu1(1);
cc.vv.socketMgr.bufferPack(e.getdata());
},
tryReconnectLogicServer: function() {
if (cc.vv.myself.playerId > 0) {
cc.vv.gameNetMgr.roomData.bNeedLoad = !0;
var e = new PacketWriter();
e.writeid(cc.vv.packid.PACKETID_104);
e.writeu8(cc.vv.myself.playerId);
e.writeu4(0);
cc.vv.socketMgr.bufferPack(e.getdata());
console.log("send 104 reconnect logic server");
}
},
onRequestPlayerInfoEvent: function(e) {
console.log("ask_" + e + "_playerInfo");
var t = new PacketWriter();
t.writeid(cc.vv.packid.PACKETID_208);
t.writeu8(e);
cc.vv.socketMgr.bufferPack(t.getdata());
}
});
cc._RF.pop();
}, {} ],
GameResource: [ function(e, t) {
"use strict";
cc._RF.push(t, "c2c0bVhMh1GBYrXqUqi8UrZ", "GameResource");
var n;
cc.Class({
extends: cc.Component,
properties: {},
statics: {
MJ_AUDIO_RES: {
MJ_AUDIO_01: "zhong",
MJ_AUDIO_02: "fa",
MJ_AUDIO_03: "bai",
MJ_AUDIO_11: "dongfeng",
MJ_AUDIO_13: "xifeng",
MJ_AUDIO_12: "nanfeng",
MJ_AUDIO_14: "beifeng",
MJ_AUDIO_21: "wan1",
MJ_AUDIO_22: "wan2",
MJ_AUDIO_23: "wan3",
MJ_AUDIO_24: "wan4",
MJ_AUDIO_25: "wan5",
MJ_AUDIO_26: "wan6",
MJ_AUDIO_27: "wan7",
MJ_AUDIO_28: "wan8",
MJ_AUDIO_29: "wan9",
MJ_AUDIO_31: "tiao1",
MJ_AUDIO_32: "tiao2",
MJ_AUDIO_33: "tiao3",
MJ_AUDIO_34: "tiao4",
MJ_AUDIO_35: "tiao5",
MJ_AUDIO_36: "tiao6",
MJ_AUDIO_37: "tiao7",
MJ_AUDIO_38: "tiao8",
MJ_AUDIO_39: "tiao9",
MJ_AUDIO_41: "tong1",
MJ_AUDIO_42: "tong2",
MJ_AUDIO_43: "tong3",
MJ_AUDIO_44: "tong4",
MJ_AUDIO_45: "tong5",
MJ_AUDIO_46: "tong6",
MJ_AUDIO_47: "tong7",
MJ_AUDIO_48: "tong8",
MJ_AUDIO_49: "tong9",
MJ_AUDIO_51: null,
MJ_AUDIO_52: null,
MJ_AUDIO_53: null,
MJ_AUDIO_54: null,
MJ_AUDIO_58: null,
MJ_AUDIO_56: null,
MJ_AUDIO_55: null,
MJ_AUDIO_57: null,
MJ_AUDIO_61: "gang",
MJ_AUDIO_62: "buhua",
MJ_AUDIO_63: "peng",
MJ_AUDIO_64: "ting",
MJ_AUDIO_65: "chi",
MJ_AUDIO_66: null,
MJ_AUDIO_67: "mahjong_drop",
MJ_AUDIO_68: "timeup_alarm",
MJ_AUDIO_69: "mahjong_select",
MJ_AUDIO_70: "mahjong_win",
MJ_AUDIO_71: "mahjong_lose",
MJ_AUDIO_72: "mahjong_huang",
MJ_AUDIO_73: null,
MJ_AUDIO_74: "guafeng",
MJ_AUDIO_75: "xlch_guafeng_small",
MJ_AUDIO_76: "xiayu",
MJ_AUDIO_77: "xlch_xiayu_small",
MJ_AUDIO_81: "woman_hu",
MJ_AUDIO_82: "woman_zimo",
MJ_AUDIO_83: "jinque",
MJ_AUDIO_84: "jinlong",
MJ_AUDIO_85: "qiangjin",
MJ_AUDIO_86: "tianhu",
MJ_AUDIO_87: "sanjindao",
MJ_AUDIO_88: "wuhuawugang",
MJ_AUDIO_89: "yizhihua",
MJ_AUDIO_101: "fix_msg_1",
MJ_AUDIO_102: "fix_msg_2",
MJ_AUDIO_103: "fix_msg_3",
MJ_AUDIO_104: "fix_msg_4",
MJ_AUDIO_105: "fix_msg_5",
MJ_AUDIO_106: "fix_msg_6",
MJ_AUDIO_107: "fix_msg_7",
MJ_AUDIO_108: "fix_msg_8",
MJ_AUDIO_109: "fix_msg_9",
MJ_AUDIO_110: "fix_msg_10",
MJ_AUDIO_111: "fix_msg_11",
get: function(e) {
if ("undefined" != typeof this["MJ_AUDIO_" + e]) {
var t = cc.vv.localData.setting, n = "resources/audio/dubbing/mahjong/" + (0 == ("undefined" != typeof t.lan_type ? t.lan_type : 0) ? "mandarin/" : "dialect/fz/") + (0 == ("undefined" != typeof t.lan_sex ? t.lan_sex : 0) ? "man/" : "woman/");
e >= 67 && e <= 73 && (n = "resources/audio/");
return n + this["MJ_AUDIO_" + e] + ".mp3";
}
return null;
}
},
MJ_HU_AUDIO_RES: (n = {
HU_5: "",
HU_6: "",
HU_7: "",
HU_8: "",
HU_9: "woman_zimo",
HU_10: "woman_hu",
HU_11: "tianhu",
HU_12: "qiangjin",
HU_13: "wuhuawugang",
HU_14: "yizhihua",
HU_15: "sanjindao",
HU_16: "jinque",
HU_17: "jinlong",
HU_22: "sijindao",
HU_23: "",
HU_24: "",
HU_27: "",
HU_37: "woman_hu",
HU_31: "",
HU_32: "",
HU_33: "",
HU_34: "",
HU_36: "tianhu"
}, n.HU_37 = "woman_hu", n.HU_38 = "woman_hu", n.HU_39 = "woman_hu", n.HU_40 = "woman_hu", 
n.HU_41 = "woman_hu", n.HU_42 = "tianhu", n.HU_43 = "woman_hu", n.HU_44 = "woman_hu", 
n.HU_45 = "woman_hu", n.HU_46 = "woman_hu", n.HU_47 = "woman_hu", n.HU_48 = "woman_hu", 
n.HU_49 = "woman_hu", n.HU_50 = "woman_hu", n.HU_51 = "tianhu", n.HU_52 = "woman_hu", 
n.HU_53 = "woman_hu", n.HU_54 = "woman_hu", n.HU_55 = "woman_hu", n.HU_56 = "woman_hu", 
n.HU_57 = "woman_hu", n.HU_58 = "woman_hu", n.HU_59 = "woman_hu", n.HU_60 = "woman_hu", 
n.HU_61 = "woman_hu", n.HU_62 = "woman_hu", n.HU_63 = "woman_hu", n.get = function(e) {
if ("undefined" != typeof this["HU_" + e]) {
var t = cc.vv.localData.setting;
return "resources/audio/dubbing/mahjong/" + (0 == ("undefined" != typeof t.lan_type ? t.lan_type : 0) ? "mandarin/" : "dialect/fz/") + (0 == ("undefined" != typeof t.lan_sex ? t.lan_sex : 0) ? "man/" : "woman/") + this["HU_" + e] + ".mp3";
}
return null;
}, n),
MJ_CMD_HU_TYPE_IMG_RES: {
TYPE_6: "battle_opt_qingyise",
TYPE_7: "battle_opt_qiduizi",
TYPE_8: "battle_opt_haohuaqiduizi",
TYPE_9: "battle_opt_zimo",
TYPE_10: "battle_opt_hu",
TYPE_11: "battle_opt_tianhu",
TYPE_12: "battle_opt_qiangjin",
TYPE_15: "battle_opt_sanjindao",
TYPE_16: "battle_opt_jinque",
TYPE_17: "battle_opt_jinlong",
TYPE_22: "battle_opt_sijindao",
TYPE_23: "battle_opt_dihu",
TYPE_24: "battle_opt_jingang",
TYPE_25: "battle_opt_dandiao",
TYPE_27: "battle_opt_hunyise",
TYPE_56: "battle_opt_jinkan",
TYPE_4007: "battle_opt_duiduihu",
TYPE_4017: "battle_opt_jinshun",
get: function(e) {
var t = cc.vv.global.GAME_TYPE;
return "undefined" != typeof this["TYPE_" + (1e3 * t + e)] ? this["TYPE_" + (1e3 * t + e)] : "undefined" != typeof this["TYPE_" + e] ? this["TYPE_" + e] : this.TYPE_10;
}
},
MJ_SIGN_HU_TYPE_IMG_RES: {
TYPE_6: "battle_hu_qingyise",
TYPE_7: "battle_hu_qiduizi",
TYPE_8: "battle_hu_haohuaqiduizi",
TYPE_9: "battle_hu_zimo",
TYPE_10: "battle_hu_hupai",
TYPE_11: "battle_hu_tianhu",
TYPE_12: "battle_hu_qiangjin",
TYPE_13: "battle_hu_wuhuawugang",
TYPE_14: "battle_hu_yizhihua",
TYPE_15: "battle_hu_sanjindao",
TYPE_16: "battle_hu_jinque",
TYPE_17: "battle_hu_jinlong",
TYPE_18: "battle_hu_youjin",
TYPE_19: "battle_hu_shuangyou",
TYPE_20: "battle_hu_sanyou",
TYPE_22: "battle_hu_sijindao",
TYPE_23: "battle_hu_dihu",
TYPE_24: "battle_hu_jingang",
TYPE_25: "battle_hu_dandiao",
TYPE_26: "battle_hu_youjin",
TYPE_27: "battle_hu_hunyise",
TYPE_56: "battle_hu_jinkan",
TYPE_4007: "battle_hu_duiduihu",
TYPE_4017: "battle_hu_jinshun",
get: function(e) {
var t = cc.vv.global.GAME_TYPE;
return "undefined" != typeof this["TYPE_" + (1e3 * t + e)] ? this["TYPE_" + (1e3 * t + e)] : "undefined" != typeof this["TYPE_" + e] ? this["TYPE_" + e] : this.TYPE_10;
}
}
},
start: function() {}
});
cc._RF.pop();
}, {} ],
GameTexture: [ function(e, t) {
"use strict";
cc._RF.push(t, "401c8x8pOxFCbPK4cqOvWDD", "GameTexture");
var n = {
wxmingamelogin: "resources/texture/btn_play.png",
wxmingamelogin_width: 195,
wxmingamelogin_height: 57
};
t.exports = n;
cc.GameTexture = n;
cc._RF.pop();
}, {} ],
GuideManage: [ function(e, t) {
"use strict";
cc._RF.push(t, "56ef0DEl5dM0qKgvPIA6kFS", "GuideManage");
cc.Class({
extends: cc.Component,
properties: {},
statics: {
curStepId: -1,
maxStepCount: 20,
guideStepConfigureArr: [],
checkGuide: function() {
if (0 == cc.vv.myself.guideStep) {
this.curStepId = 0;
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_MATCH_GAME);
}
1 == cc.vv.myself.guideStep && (this.curStepId = 13);
2 == cc.vv.myself.guideStep && (this.curStepId = 20);
this.guideStepConfigureArr = [];
this.curStepId < this.maxStepCount && this.dealGuide();
},
dealGuide: function() {
"undefined" == typeof this.guideStepConfigureArr[this.curStepId] || null == this.guideStepConfigureArr[this.curStepId] ? this.initConfigure() : this.startGuide();
},
startGuide: function() {
cc.vv.utils.showGuideNode(this.guideStepConfigureArr[this.curStepId]);
},
doneGuideStep: function() {
this.curStepId += 1;
this.curStepId < this.maxStepCount && this.dealGuide();
},
initConfigure: function() {
this["setConfigure_" + this.curStepId]();
this.startGuide();
},
onSendGuideStepEvent: function(e) {
var t = new PacketWriter();
t.writeid(cc.vv.packid.PACKETID_242);
t.writeu1(e);
cc.vv.socketMgr.bufferPack(t.getdata());
cc.vv.myself.guideStep = e;
},
setConfigure_0: function() {
var e = this, t = cc.find("Canvas/head/item_3"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 300;
n.offsetY = -120;
n.arrow = "lt";
n.infoStr = cc.vv.lan.MATCH_LAN[65];
n.bInfoImg = !0;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_HELP, null, function() {
e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[0] = n;
},
setConfigure_1: function() {
var e = this, t = cc.find("Canvas/help/bg_spr"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 200;
n.offsetY = -280;
n.arrow = "lt";
n.infoStr = cc.vv.lan.MATCH_LAN[66];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
t.parent.getComponent("Help").onCloseBtnClicked();
e.doneGuideStep();
}, this.guideStepConfigureArr[1] = n;
},
setConfigure_2: function() {
var e = this, t = cc.find("Canvas/guide_match_canvas/right/match_enroll_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 10;
n.offsetY = 160;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[69];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
n.widget.active = !1;
cc.vv.utils.showDialogOKCancel(cc.vv.lan.MATCH_LAN[7].format(15), function() {}, function() {}, !0, cc.vv.enum.EnumLabelHorizontalAlign.LEFT, function() {
this.wechatConcernBtn.node.active = !0;
this.cancelBtn.node.active = !1;
e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[2] = n;
},
setConfigure_3: function() {
var e = this, t = cc.find("Canvas/dialog/dialog_bg"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 110;
n.offsetY = -260;
n.arrow = "lt";
n.infoStr = cc.vv.lan.MATCH_LAN[70];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
var t = cc.find("Canvas/dialog");
t && t.destroy();
e.doneGuideStep();
}, this.guideStepConfigureArr[3] = n;
},
setConfigure_4: function() {
var e = this, t = cc.find("Canvas/guide_match_canvas/right/match_award_tip_lbl"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -45;
n.offsetY = 130;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[71];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
e.doneGuideStep();
}, this.guideStepConfigureArr[4] = n;
},
setConfigure_5: function() {
var e = this, t = cc.find("Canvas/guide_match_canvas/right/match_enter_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -45;
n.offsetY = 140;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[72];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
var t = cc.find("Canvas/guide_match_canvas");
t && t.destroy();
cc.eventManager.pauseTarget(cc.find("Canvas"), !0);
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_MJ_BATTLE, null, function() {
e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[5] = n;
},
setConfigure_6: function() {
var e = this, t = cc.find("Canvas/guide_mj_battle_node/guideNode"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 20;
n.offsetY = -200;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[73];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
t.parent.getComponent("GuideMJBattle").onHideCountDownComponent();
e.doneGuideStep();
}, this.guideStepConfigureArr[6] = n;
},
setConfigure_7: function() {
var e = this, t = cc.find("Canvas/guide_mj_battle_node/guideNode"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -45;
n.offsetY = 0;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[74];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 2;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
t.parent.getComponent("GuideMJBattle").onShowGuideBattleCardComponent();
cc.find("Canvas/guide_node").active = !1;
e.doneGuideStep();
}, this.guideStepConfigureArr[7] = n;
},
setConfigure_8: function() {
var e = this, t = cc.find("Canvas/guide_mj_battle_node/guide_card/game/bottom/MyCmd/opt_gold_camp"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -80;
n.offsetY = 180;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[83];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 0;
n.holeCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.find("Canvas/guide_mj_battle_node").getComponent("GuideMJBattle").onHideGuideBattleCardComponent();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_MJ_ROUND_RESULT, null, function(t) {
t.getComponent("GuideMJRoundResult")._callback = e.doneGuideStep();
});
}, this.guideStepConfigureArr[8] = n;
},
setConfigure_9: function() {
var e = this, t = cc.find("Canvas/guide_mj_round_result_node/continue_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 0;
n.offsetY = 200;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[88];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 1;
n.holeCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.find("Canvas/guide_mj_battle_node").getComponent("GuideMJBattle").onHideGuideBattleCardComponent();
var t = cc.find("Canvas/guide_mj_round_result_node");
t && t.destroy();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_MJ_COMPLETED, null, function() {
e.doneGuideStep();
});
}, n.nextCallFunc = n.holeCallFunc;
this.guideStepConfigureArr[9] = n;
},
setConfigure_10: function() {
var e = this, t = cc.find("Canvas/guide_mj_battle_completed/back_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 20;
n.offsetY = 130;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[75];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
e.onSendGuideStepEvent(1);
var t = cc.find("Canvas/guide_mj_battle_completed"), n = cc.find("Canvas/guide_mj_battle_node");
t && t.destroy();
n && n.destroy();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_MJ_AWARD, null, function(t) {
t.getComponent("GuideMJAward")._callback = e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[10] = n;
},
setConfigure_11: function() {
var e = this, t = cc.find("Canvas/guide_mj_match_award/share_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 20;
n.offsetY = 160;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[76];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
e.doneGuideStep();
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[11] = n;
},
setConfigure_12: function() {
var e = this, t = cc.find("Canvas/guide_mj_match_award/back_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 395;
n.offsetY = -90;
n.arrow = "lt";
n.infoStr = cc.vv.lan.MATCH_LAN[77];
n.bInfoImg = !1;
n.chickIdx = 2;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
var t = cc.find("Canvas/guide_mj_match_award");
t && t.destroy();
e.doneGuideStep();
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[12] = n;
},
setConfigure_13: function() {
var e = this, t = cc.find("Canvas/left/panel_1"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 500;
n.offsetY = -150;
n.arrow = "lt";
n.infoStr = cc.vv.lan.MATCH_LAN[78];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_DRAW_MONEY, null, function() {
e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[13] = n;
},
setConfigure_14: function() {
var e = this, t = cc.find("Canvas/draw_money/draw_bonus_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 120;
n.offsetY = -140;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[79];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_DRAW_MONEY_TUTORIAL, null, function() {
e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[14] = n;
},
setConfigure_15: function() {
var e = this, t = cc.find("Canvas/draw_money_tutorial/tutorial_content"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -260;
n.offsetY = -255;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[80];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
e.doneGuideStep();
}, this.guideStepConfigureArr[15] = n;
},
setConfigure_16: function() {
var e = this, t = cc.find("Canvas/draw_money_tutorial/tutorial_down/concern_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = -80;
n.offsetY = 150;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[80];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_WECHAT_CONCERN, null, function(t) {
t.getComponent("Help")._callback = e.doneGuideStep();
});
}, n.holeCallFunc = n.nextCallFunc;
this.guideStepConfigureArr[16] = n;
},
setConfigure_17: function() {
var e = this, t = cc.find("Canvas/wechat_concern/panel"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 100;
n.offsetY = -260;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[90];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
e.doneGuideStep();
}, this.guideStepConfigureArr[17] = n;
},
setConfigure_18: function() {
var e = cc.find("Canvas/wechat_concern/arrow_spr"), t = e.parent.convertToWorldSpaceAR(cc.p(e.x, e.y)), n = {
typ: 2
};
n.x = t.x - 157;
n.y = t.y;
n.width = e.width;
n.height = e.height;
n.offsetX = -120;
n.offsetY = -130;
n.arrow = "rt";
n.infoStr = cc.vv.lan.MATCH_LAN[81];
n.bInfoImg = !1;
n.chickIdx = 1;
n.nextStepIdx = 1;
var o = this;
n.nextCallFunc = function() {
cc.vv.audioMgr.playClickedBgm();
var e = cc.find("Canvas/wechat_concern"), t = cc.find("Canvas/draw_money"), n = cc.find("Canvas/draw_money_tutorial");
e && e.destroy();
t && t.destroy();
n && n.destroy();
cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GUIDE_CLICK_ANIM, null, function() {
o.doneGuideStep();
});
}, this.guideStepConfigureArr[18] = n;
},
setConfigure_19: function() {
var e = this, t = cc.find("Canvas/right/match_enroll_btn"), n = {
typ: 1
};
n.widget = t;
n.offsetX = 35;
n.offsetY = 150;
n.arrow = "rb";
n.infoStr = cc.vv.lan.MATCH_LAN[82];
n.bInfoImg = !1;
n.chickIdx = 0;
n.nextStepIdx = 0;
n.maskBgOpacity = 0;
n._bHideMask = !0;
n.holeCallFunc = function() {
e.onSendGuideStepEvent(2);
var t = cc.find("Canvas/guide_clickAnim");
t && t.destroy();
cc.find("Canvas").getComponent("Match").onEnrollMatchEvent();
cc.eventManager.resumeTarget(cc.find("Canvas"), !0);
}, n.maskCallFunc = function() {
e.onSendGuideStepEvent(2);
cc.eventManager.resumeTarget(cc.find("Canvas"), !0);
var t = cc.find("Canvas/guide_clickAnim");
t && t.destroy();
}, n.nextCallFunc = n.maskCallFunc;
this.guideStepConfigureArr[19] = n;
}
}
});
cc._RF.pop();
}, {} ],
Hall: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "a94d9ZkrxlDp4L9XJ9kkKd+", "Hall");
var o, a = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
o(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), c = this && this.__decorate || function(e, t, n, o) {
var a, c = arguments.length, i = c < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var s = e.length - 1; s >= 0; s--) (a = e[s]) && (i = (c < 3 ? a(i) : c > 3 ? a(t, n, i) : a(t, n)) || i);
return c > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var i = cc._decorator, s = i.ccclass, r = i.property, l = function(e) {
a(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.start = function() {
this.initListenHandlers();
var e = Date.parse(new Date()) / 1e3, t = cc.Utils.getTimeStampToNow(e, [ "/", "/", "" ], "ALL");
cc.find("Canvas/n_layout/l_nowTime_value").getComponent(cc.Label).string = t;
setInterval(function() {
var e = Date.parse(new Date()) / 1e3, t = cc.Utils.getTimeStampToNow(e, [ "/", "/", "" ], "ALL");
cc.find("Canvas/n_layout/l_nowTime_value").getComponent(cc.Label).string = t;
}, 1e3);
};
t.prototype.initListenHandlers = function() {
this.lCountDown.on(cc.Node.EventType.TOUCH_START, this.onLCountDownTouchEvent, this);
};
t.prototype.onLCountDownTouchEvent = function() {
if (this.inputNode) {
this.inputNode.y = 0;
this.inputNode.opacity = 255;
this.inputNode.getComponent("InputNumber").onResetBtnClicked();
} else {
this.inputNode = cc.instantiate(this.inputNumber);
this.node.addChild(this.inputNode);
}
};
c([ r({
displayName: "倒计时文本",
type: cc.Node
}) ], t.prototype, "lCountDown", void 0);
c([ r({
displayName: "数字按键预制",
type: cc.Prefab
}) ], t.prototype, "inputNumber", void 0);
return c([ s ], t);
}(cc.Component);
n.default = l;
cc._RF.pop();
}, {} ],
InputNumber: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "3836avgHaRHJZvbu/1ZZ4Pj", "InputNumber");
var o, a = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
o(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), c = this && this.__decorate || function(e, t, n, o) {
var a, c = arguments.length, i = c < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, o); else for (var s = e.length - 1; s >= 0; s--) (a = e[s]) && (i = (c < 3 ? a(i) : c > 3 ? a(t, n, i) : a(t, n)) || i);
return c > 3 && i && Object.defineProperty(t, n, i), i;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var i = cc._decorator, s = i.ccclass, r = i.property, l = function(e) {
a(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t._inputCount = 0;
t._timeNum = [];
return t;
}
t.prototype.start = function() {
this.initListenHandlers();
};
t.prototype.initListenHandlers = function() {
var e = this;
cc.find("content/title", this.node).on(cc.Node.EventType.TOUCH_START, function() {
e.closePanelEvent();
});
};
t.prototype.closePanelEvent = function() {
this.node.y = -640;
this.node.opacity = 0;
this._inputCount = 0;
};
t.prototype.onNumBtnClicked = function(e, t) {
if (this._inputCount < 6) {
2 !== this._inputCount && 4 != this._inputCount || t >= 6 && (t = 5);
this._timeNum[this._inputCount] = t;
this.inputBox.children[this._inputCount].children[0].getComponent(cc.Label).string = t;
this._inputCount++;
if (6 == this._inputCount) {
this.closePanelEvent();
var n = Number(this._timeNum[0] + this._timeNum[1]), o = Number(this._timeNum[2] + this._timeNum[3]), a = Number(this._timeNum[4] + this._timeNum[5]), c = new Date(), i = c.getUTCFullYear(), s = Number(c.getUTCMonth()) + 1, r = s < 10 ? "0" + s : s, l = Number(c.getUTCDate()), u = l < 10 ? "0" + l : l, d = Date.parse(r + " " + u + " " + i + " " + n + ":" + o + ":" + a), _ = cc.Utils.formatDuring(d);
cc.find("Canvas/n_layout/l_countDown").getComponent(cc.Label).string = _;
cc.find("Canvas/n_layout/l_countDown").getComponent("CountDown")._nextTime = d;
}
}
};
t.prototype.onResetBtnClicked = function() {
for (var e = 0; e < this.inputBox.children.length; e++) this.inputBox.children[e].children[0].getComponent(cc.Label).string = "";
};
t.prototype.onCleanBtnClicked = function() {
if (0 != this._inputCount) {
this.inputBox.children[this._inputCount - 1].children[0].getComponent(cc.Label).string = "";
this._inputCount--;
}
};
c([ r({
type: cc.Integer
}) ], t.prototype, "_inputCount", void 0);
c([ r({
type: cc.Node,
displayName: "数字输入框"
}) ], t.prototype, "inputBox", void 0);
return c([ s ], t);
}(cc.Component);
n.default = l;
cc._RF.pop();
}, {} ],
Utils: [ function(e, t) {
"use strict";
cc._RF.push(t, "c2b9cLpXMxLy41Nefw87T4z", "Utils");
String.prototype.format = function(e) {
var t = this;
if (arguments.length > 0) if (1 == arguments.length && "object" == typeof e) {
for (var n in e) if (null != e[n]) {
var o = new RegExp("({" + n + "})", "g");
t = t.replace(o, e[n]);
}
} else for (var a = 0; a < arguments.length; a++) if (null != arguments[a]) {
o = new RegExp("({)" + a + "(})", "g");
t = t.replace(o, arguments[a]);
}
return t;
};
var n = {
addClickEvent: function(e, t, n, o) {
console.log(n + ":" + o);
var a = new cc.Component.EventHandler();
a.target = t;
a.component = n;
a.handler = o;
e.getComponent(cc.Button).clickEvents.push(a);
},
addSlideEvent: function(e, t, n, o) {
var a = new cc.Component.EventHandler();
a.target = t;
a.component = n;
a.handler = o;
e.getComponent(cc.Slider).slideEvents.push(a);
},
addEscEvent: function(e) {
cc.eventManager.addListener({
event: cc.EventListener.KEYBOARD,
onKeyPressed: function() {},
onKeyReleased: function(e) {
e == cc.KEY.back && cc.vv.alert.show("提示", "确定要退出游戏吗？", function() {
cc.game.end();
}, !0);
}
}, e);
},
setHeadAvatar: function(e, t, n) {
if (t.length > 0) {
if (1 == n) {
if (-1 != (o = t.lastIndexOf("/"))) {
t = t.substring(0, o);
t += "/0";
}
} else {
var o;
if (-1 != (o = t.lastIndexOf("/0"))) {
t = t.substring(0, o);
t += "/96";
}
}
if ("undefined" != typeof e.avatarUrl && e.avatarUrl === t) return;
var a = e, c = t;
cc.loader.load({
url: t,
type: "png"
}, function(e, t) {
if (cc.isValid(a.node)) if (!e && a) {
a.spriteFrame = new cc.SpriteFrame();
a.spriteFrame.setTexture(t);
a.avatarUrl = c;
} else a.spriteFrame = cc.vv.atlas.main.getSpriteFrame(cc.vv.const.DEFAULT_HEAD_AVATAR_FRAME_NAME);
});
} else {
if ("undefined" != typeof e.avatarUrl && e.avatarUrl === cc.vv.const.DEFAULT_HEAD_AVATAR_FRAME_NAME) return;
e.spriteFrame = cc.vv.atlas.main.getSpriteFrame(cc.vv.const.DEFAULT_HEAD_AVATAR_FRAME_NAME);
}
},
createPrefabByUrl: function(e, t, n) {
cc.loader.loadRes(e, function(e, t) {
cc.vv.loading && cc.vv.loading.updateView(e, t);
}, function(e, o) {
var a = cc.instantiate(o);
null == t ? cc.find("Canvas").addChild(a) : t.addChild(a);
"function" == typeof n && n(a);
});
},
showDialogOK: function(e, t, n, o, a) {
console.log("[Utils.showDialogOK] message = " + e);
cc.loader.loadRes("prefabs/dialog", function(c, i) {
if (c) {
console.log("[Utils.showDialogOK] load callback");
console.log(c);
} else {
var s = "undefind" !== n && n;
o = null == o ? cc.vv.enum.EnumLabelHorizontalAlign.CENTER : o;
var r = cc.director.getScene(), l = cc.instantiate(i);
l.getComponent("Dialog").init(e, s, !0, !1, !0, t, null, o, null, a);
l.parent = r.children[0];
}
});
},
showDialogCancel: function(e, t, n, o) {
console.log("[Utils.showDialogCancel] message = " + e);
cc.loader.loadRes("prefabs/dialog", function(a, c) {
if (a) {
console.log("[Utils.showDialogCancel] load callback");
console.log(a);
} else {
var i = "undefined" !== n && n, s = cc.director.getScene(), r = cc.instantiate(c);
r.getComponent("Dialog").init(e, i, !1, !0, !0, null, t, null, null, null, o);
r.parent = s.children[0];
}
});
},
showDialogOKCancel: function(e, t, n, o, a, c) {
console.log("[Utils.showDialogOKCancel] message = " + e);
cc.loader.loadRes("prefabs/dialog", function(i, s) {
if (i) {
console.log("[Utils.showDialogOKCancel] load callback");
console.log(i);
} else {
var r = "undefined" !== o && o;
a = "undefind" === a ? cc.vv.enum.EnumLabelHorizontalAlign.CENTER : a;
var l = cc.director.getScene(), u = cc.instantiate(s);
u.getComponent("Dialog").init(e, r, !0, !0, !0, t, n, a, c);
u.parent = l.children[0];
}
});
},
showDialogOKOnly: function(e, t, n, o) {
console.log("[Utils.showDialogOKCancel] message = " + e);
cc.loader.loadRes("prefabs/dialog", function(a, c) {
if (a) {
console.log("[Utils.showDialogOKCancel] load callback");
console.log(a);
} else {
var i = "undefined" !== n && n, s = cc.director.getScene(), r = cc.instantiate(c);
r.getComponent("Dialog").init(e, i, !0, !1, !1, t, null);
r.parent = s.children[0];
null != o && (r.zIndex = o);
}
});
},
showFlyTip: function(e, t) {
console.log("[Utils.showFlyTip] str = " + e);
cc.loader.loadRes("prefabs/fly_tip_node", function(n, o) {
if (n) {
console.log("[Utils.showFlyTip] load callback");
console.log(n);
} else {
var a = cc.director.getScene(), c = cc.instantiate(o);
c.parent = a;
c.getComponent("FlyTip").updateTip(e);
"function" == typeof t && t();
}
});
},
getTimeStampToNow: function(e, t, n) {
var o = (e = new Date(1e3 * e)).getFullYear() + t[0], a = (e.getMonth() + 1 < 10 ? +(e.getMonth() + 1) : e.getMonth() + 1) + t[1], c = (e.getDate() < 10 ? +e.getDate() : e.getDate()) + t[2], i = " " + (e.getHours() < 10 ? "0" + e.getHours() : e.getHours()) + ":", s = (e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":", r = e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds();
return "ALL" === n ? o + a + c + i + s + r : "YMD" === n ? o + a + c : "MD" === n ? a + c : "HMS" === n ? i + s + r : void 0;
},
getStrByTimeStamp: function(e, t, n) {
var o = !0, a = [ cc.vv.lan.MATCH_LAN[22], cc.vv.lan.MATCH_LAN[23], cc.vv.lan.MATCH_LAN[24], cc.vv.lan.MATCH_LAN[25], cc.vv.lan.MATCH_LAN[2], cc.vv.lan.MATCH_LAN[3] ];
if ("undefined" != typeof n && null != n) {
a = [ n, n, "", ":", ":", "" ];
o = !1;
}
var c = new Date(1e3 * e), i = {};
i.y = c.getFullYear();
i.M = c.getMonth() + 1 < 10 ? "0" + (c.getMonth() + 1) : c.getMonth() + 1;
i.d = c.getDate() < 10 ? "0" + c.getDate() : c.getDate();
i.H = c.getHours() < 10 ? "0" + c.getHours() : c.getHours();
i.m = c.getMinutes() < 10 ? "0" + c.getMinutes() : c.getMinutes();
i.s = c.getSeconds() < 10 ? "0" + c.getSeconds() : c.getSeconds();
for (var s = "", r = 0; r < t.length; r++) {
"H" == t[r] && r > 0 && (s += " ");
s += i[t[r]];
(r + 1 < t.length || o) && (s += a["yMdHms".indexOf(t[r])]);
}
return s;
},
formatDuring: function(e, t) {
void 0 === t && (t = e, e = Date.now());
var n = (t - e) % 864e5, o = Math.floor(n / 36e5), a = o < 10 ? "0" + o : o, c = n % 36e5, i = Math.floor(c / 6e4), s = i < 10 ? "0" + i : i, r = c % 6e4, l = Math.round(r / 1e3);
return a + ":" + s + ":" + (l < 10 ? "0" + l : l);
},
shareGame: function(e, t, n, o, a) {
if (cc.vv.wxHelper.iswxPlatform()) {
if (null != o) var c = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName + "&inviterMatchId=" + cc.vv.matchData.matchId + "&inviterSceneID=" + a; else c = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName + "&inviterSceneID=" + a;
t = t;
if (null == (e = e) && null == t) {
e = cc.vv.lan.SHARE_TITLE_GAME;
t = cc.vv.const.WX_SHARE_GAME_URL;
}
null != n ? cc.vv.wxHelper.updateShareMenu(n, function() {
cc.vv.wxHelper.shareAppMessageQuery(e, t, c, null, null, a);
}) : cc.vv.wxHelper.updateShareMenu(!1, function() {
cc.vv.wxHelper.shareAppMessageQuery(e, t, c, null, null, a);
});
} else console.log("not wx platform.");
},
shareAward: function(e, t) {
if (cc.vv.wxHelper.iswxPlatform()) {
var n = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName + "&inviterSceneID=" + t;
null != e ? cc.vv.wxHelper.updateShareMenu(e, function() {
cc.vv.wxHelper.shareAppMessageQuery(cc.vv.lan.SHARE_TITLE_AWARD, cc.vv.const.WX_SHARE_AWARD_URL, n, null, null, t);
}) : cc.vv.wxHelper.updateShareMenu(!1, function() {
cc.vv.wxHelper.shareAppMessageQuery(cc.vv.lan.SHARE_TITLE_AWARD, cc.vv.const.WX_SHARE_AWARD_URL, n, null, null, t);
});
} else console.log("not wx platform.");
},
shareGameWithCallBackEvent: function(e, t, n, o, a, c) {
if (cc.vv.wxHelper.iswxPlatform()) {
var i = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName + "&inviterSceneID=" + c, s = !1;
null != n && (s = n);
cc.vv.wxHelper.updateShareMenu(s, function() {
cc.vv.wxHelper.shareAppMessageQuery(e, t, i, o, a, c);
});
} else console.log("not wx platform.");
},
shareGroupRankEvent: function(e, t, n) {
if (cc.vv.wxHelper.iswxPlatform()) {
console.log("shareGroupRankEvent");
var o = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName + "&inviterInitType=1&inviterInitModule=" + cc.vv.enum.EnumInitView.EIV_GROUP + "&inviterSceneID=" + n;
t = t;
if (null == (e = e) && null == t) {
e = cc.vv.lan.SHARE_TITLE_GAME;
t = cc.vv.const.WX_SHARE_GAME_URL;
}
cc.vv.wxHelper.updateShareMenu(!0, function() {
cc.vv.wxHelper.shareAppMessageQuery(e, t, o, null, null, n);
});
} else console.log("not wx platform.");
},
getSubstringDataByLength: function(e, t, n) {
null == t && (t = cc.vv.const.SUBSTRING_MAXLENGTH);
null == n && (n = cc.vv.const.SUBSTRING_LENGTH);
var o = [], a = 0, c = e.split("");
if (this.getStringDataLength(e) <= t) return e;
for (var i = 0; i < e.length; i++) {
var s = c[i];
if (a < n) {
s.match(/[\x21-\x2f\x3a-\x40\x5b-\x60\x7B-\x7F]/g) ? a += .5 : s.match(/[^\x00-\xff]/g) ? a += 2 : s.match(/^[a-zA-Z\d]+$/g) && (a += 1);
o.push(s);
}
}
return o.join("") + "...";
},
getStringDataLength: function(e) {
for (var t = 0, n = e.split(""), o = 0; o < e.length; o++) {
var a = n[o];
a.match(/[\x21-\x2f\x3a-\x40\x5b-\x60\x7B-\x7F]/g) ? t += .5 : a.match(/[^\x00-\xff]/g) ? t += 2 : a.match(/^[a-zA-Z\d]+$/g) && (t += 1);
}
return t;
},
getWeightArr: function(e) {
for (var t = [], n = 0; n < e.length; n++) -1 == t.indexOf(e[n]) && t.push(e[n]);
return t;
},
getTimeStampByString: function(e) {
var t = e.replace(/-/g, "/");
return Date.parse(t) / 1e3;
},
showGuideNode: function(e) {
cc.loader.loadRes("prefabs/guide_node", function(t, n) {
var o = cc.instantiate(n);
o.zIndex = 1e3;
o.parent = cc.find("Canvas");
o.active = !0;
o.getComponent("GuideNode").init(e);
});
},
toDecimalByLen: function(e, t) {
null == t && (t = cc.vv.const.HOLDNUM_LEN);
var n = parseFloat(e);
if (isNaN(n)) return !1;
var o = Math.pow(10, t), a = (n = Math.floor(e * o) / o).toString(), c = a.indexOf(".");
if (c < 0) {
c = a.length;
a += ".";
}
for (;a.length <= c + t; ) a += "0";
return a;
},
getGoldShow: function(e) {
if (e > 99999 && e < 1e8) {
var t = e / 1e4;
0 != cc.vv.utils.getDigit(t) ? e < 1e5 ? e = this.toDecimalByLen(t, 3) + cc.vv.lan.MATCH_LAN[109] : e >= 1e5 && e < 1e6 ? e = this.toDecimalByLen(t, 2) + cc.vv.lan.MATCH_LAN[109] : e >= 1e6 && e < 1e7 ? e = this.toDecimalByLen(t, 1) + cc.vv.lan.MATCH_LAN[109] : e >= 1e7 && (e = Math.floor(t) + cc.vv.lan.MATCH_LAN[109]) : e = t + cc.vv.lan.MATCH_LAN[109];
} else if (e >= 1e8) {
t = e / 1e8;
0 != cc.vv.utils.getDigit(t) ? e < 1e9 ? e = this.toDecimalByLen(t, 3) + cc.vv.lan.MATCH_LAN[129] : e >= 1e9 && e < 1e10 ? e = this.toDecimalByLen(t, 2) + cc.vv.lan.MATCH_LAN[129] : e >= 1e10 && e < 1e11 ? e = this.toDecimalByLen(t, 1) + cc.vv.lan.MATCH_LAN[129] : e >= 1e11 && (e = Math.floor(t) + cc.vv.lan.MATCH_LAN[129]) : e = t + cc.vv.lan.MATCH_LAN[129];
}
return e;
},
getDigit: function(e) {
var t = 0, n = 0, o = e - Math.floor(e);
if (0 != o) for (var a = 0; a < 3; a++) {
var c = (o *= 10).toString().split(".");
n = c[0];
if (0 == (o = c[1])) {
0 != n && (t += 1);
return t;
}
t += 1;
}
return t;
},
returnToHall: function() {
for (var e = cc.find("Canvas").getComponent("Match")._initChildNameArr, t = cc.find("Canvas").children, n = t.length - 1; n >= 0; n--) {
for (var o = !1, a = 0; a < e.length; a++) if (t[n].name == e[a] || "mj_battle_node" == t[n].name) {
o = !0;
break;
}
o || t[n].destroy();
}
},
secondToCountDown: function(e) {
var t = Math.floor(e / 3600), n = Math.floor(e % 3600 / 60), o = e % 3600 % 60, a = "";
a += t < 10 ? "0" + t : t;
a += ":";
a += n < 10 ? "0" + n : n;
return (a += ":") + (o < 10 ? "0" + o : o);
},
getRandomInt: function(e, t) {
return Math.floor(Math.random() * (t - e + 1)) + e;
},
getTenThousandBesidesValue: function(e) {
return e > 1e4 ? e / 1e4 : e;
},
getNodeByName: function(e) {
var t = [];
if (cc.find("Canvas").getChildByName(e)) {
t.bool = !0;
t.view = cc.find("Canvas").getChildByName(e);
return t;
}
t.bool = !1;
return t;
},
closeViewFunction: function(e) {
e.getComponent(cc.Animation).on("finished", function() {
e.destroy();
});
e.getComponent(cc.Animation).play("close_view");
},
getNowTimeStamp: function() {
return Date.parse(new Date()) / 1e3;
},
getPointNum: function(e, t) {
t = t || 3;
for (var n = 1, o = "", a = 0; a < t; a++) n *= 10;
for (var c = 0, i = 1; i > 0; i++) {
if (!(e / n >= 1)) {
0 != e && (o = "" != o ? e + "," + o : e);
break;
}
c = (Array(3).join(0) + e % n).slice(-3);
o = "" != o ? c + "," + o : c;
e = Math.floor(e / n);
}
"" == o && (o = "0");
return o;
},
getBestRecord: function() {
cc.DataUser.gameStatus === cc.GameStatus.Win && (cc.DataUser.bestRecord ? cc.DataUser.bestRecord = cc.DataUser.bestRecord > cc.DataUser.currentRecord ? cc.DataUser.currentRecord : cc.DataUser.bestRecord : cc.DataUser.bestRecord = cc.DataUser.currentRecord);
return cc.DataUser.bestRecord;
},
getTimeString: function(e) {
var t = 0, n = 0, o = 0, a = null, c = null, i = null;
if (0 <= e && e < 60) a = t = e; else if (60 <= e && e < 3600) {
a = t = e % 60;
c = n = Math.floor(e / 60);
} else {
if (!(3600 <= e && e < 36e4)) return cc.GameLanguage.zhLanguage[8];
a = t = e % 60;
c = n = Math.floor(e / 60) % 60;
i = o = Math.floor(e / 3600);
}
t < 10 && (a = "0" + t);
n < 10 && (c = "0" + n);
o < 10 && (i = "0" + o);
return cc.GameLanguage.zhLanguage[5].format(i, c, a);
},
randomNum: function(e, t) {
switch (arguments.length) {
case 1:
return parseInt(Math.random() * e + 1, 10);

case 2:
return parseInt(Math.random() * (t - e + 1) + e, 10);

default:
return 0;
}
}
};
t.exports = n;
cc.Utils = n;
cc._RF.pop();
}, {} ],
WXHelper: [ function(e, t) {
"use strict";
cc._RF.push(t, "1a5393KCIVL4IkLI8+zmaQ5", "WXHelper");
var n = {
authScopeUserInfo: !1,
sessionID: null,
isLoadingShow: !1,
requestURL: null,
inited: !1,
userInfoBtn: null,
downloadTotalCountArr: [],
downloadCompleteCountArr: [],
downloadProgress: 0,
openId: null,
weChatKey: [ "bonusPoint", "masterPoint", "answerTime" ],
RankHeight: [ 320 ],
shareTicket: null,
scene: null,
_initGroupRankIndex: 0,
_isReadyGroupRank: !0,
_isShowGroupRank: !1,
_groupRankNode: null,
_groupRankCanvasWidth: 801,
_groupRankCanvasHeight: 401.951,
_isCollect: !1,
_queryData: null,
init: function() {
var e = this;
if (!this.inited) {
this.requestURL = cc.vv.const.WX_REQUEST_URL;
this.keepScreenOn();
wx.onHide(function() {
console.log("[wx.onHide] callback");
var t = cc.find("Canvas/group_rank");
e._groupRankNode = t;
if (t) {
e._isShowGroupRank = !0;
e._isReadyGroupRank = !0;
} else e._isShowGroupRank = !1;
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_ENTER_BACKGROUND);
});
wx.onShow(function(t) {
console.log("[wx.onShow] callback");
console.log(t);
e.keepScreenOn();
if (t.scene == cc.vv.const.WX_SCENE_VALUE_1044 && !cc.vv.matchData.isMatch() && 2 == cc.vv.myself.guideStep && "undefined" != typeof t.query.inviterId && e._isReadyGroupRank) {
wx.postMessage({
command: "groupRank",
shareTicket: t.shareTicket,
keyData: e.weChatKey,
myOpenId: e.openId,
initGroupIndex: e._initGroupRankIndex
});
e._isShowGroupRank && e._groupRankNode.getComponent("GroupRank").initView(e._initGroupRankIndex, !0);
e._isShowGroupRank || "1" == t.query.inviterInitType && t.query.inviterInitModule == cc.vv.enum.EnumInitView.EIV_GROUP && t.query.inviterInitType && t.query.inviterInitModule && cc.vv.utils.createPrefabByUrl(cc.vv.const.URL_GROUP_RANK, null, function(t) {
t.getComponent("GroupRank").initView(e._initGroupRankIndex, !0);
});
}
if (t.query) {
e._queryData = t.query;
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_WX_QUERY, t.query);
}
t.scene == cc.vv.const.WX_SCENE_VALUE_1104 && (e._isCollect = !0);
cc.vv.gameNetMgr.tryReconnectLogicServer();
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_ENTER_FOREGROUND);
});
wx.onAudioInterruptionBegin(function() {
console.log("[wx.onAudioInterruptionBegin] callback");
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_AUDIO_INTERRUPTION_BEGIN);
});
wx.onAudioInterruptionEnd(function() {
console.log("[wx.onAudioInterruptionEnd] callback");
cc.vv.gameEvent.dispatchEvent(cc.vv.gameEvent.EVENT_AUDIO_INTERRUPTION_END);
});
wx.onShareAppMessage(function() {
var e = "";
"undefined" != typeof cc.vv && "undefined" != typeof cc.vv.myself && "undefined" != typeof cc.vv.myself.playerId && "undefined" != typeof cc.vv.myself.playerName && (e = "inviterId=" + cc.vv.myself.playerId + "&inviterName=" + cc.vv.myself.playerName);
return {
title: cc.vv.lan.SHARE_TITLE_GAME,
query: e,
imageUrl: cc.vv.const.WX_SHARE_GAME_URL
};
});
if ("function" == typeof wx.getUpdateManager) {
var t = wx.getUpdateManager();
t.onCheckForUpdate(function(e) {
console.log("[wx.onCheckForUpdate]");
console.log(e.hasUpdate);
});
t.onUpdateReady(function() {
console.log("[wx.onUpdateReady]");
t.applyUpdate();
});
t.onUpdateFailed(function() {
console.log("[wx.onUpdateFailed]");
});
}
this.inited = !0;
}
},
iswxPlatform: function() {
return cc.sys.platform === cc.sys.WECHAT_GAME;
},
setClipboardData: function(e, t) {
if (this.iswxPlatform()) wx.setClipboardData({
data: e,
success: function() {
"function" == typeof t && t();
}
}); else {
var n = function(t) {
t.clipboardData.setData("text/plain", e);
t.preventDefault();
}.bind(this);
document.addEventListener("copy", n);
document.execCommand("copy");
document.removeEventListener("copy", n);
}
},
showLoading: function() {
console.log("[WXHelper.showLoading]");
},
hideLoading: function() {
console.log("[WXHelper.hideLoading]");
if (this.isLoadingShow) {
console.log("[wx.hideLoading]");
wx.hideLoading();
this.isLoadingShow = !1;
}
},
showShareMenu: function() {
console.log("[WXHelper.showShareMenu]");
wx.showShareMenu();
},
updateShareMenu: function(e, t) {
wx.updateShareMenu({
withShareTicket: e,
success: function() {
console.log("updateShareMenu success");
"function" == typeof t && t();
},
fail: function() {
console.log("updateShareMenu fail");
}
});
},
getShareInfo: function(e, t) {
var n = this;
wx.getShareInfo({
shareTicket: e,
success: function(e) {
console.log("getShareInfo success");
console.log(e);
e.errMsg;
var o = e.encryptedData, a = e.iv;
wx.request({
url: n.requestURL + "decrypt",
data: {
sessionID: n.sessionID,
encryptedData: o,
iv: a
},
method: "POST",
success: function(e) {
console.log("[wx.getUserInfo.request] success.");
console.log(e);
console.log(e.data);
200 === e.statusCode && "function" == typeof t && t(e.data.Data.openGId);
},
fail: function() {
console.log("[wx.getShareInfo.request] fail.");
},
complete: function() {
console.log("[wx.getShareInfo.request] complete.");
}
});
},
fail: function() {
console.log("getShareInfo fail");
},
complete: function() {
console.log("getShareInfo complete");
}
});
},
hideShareMenu: function() {
console.log("[WXHelper.hideShareMenu]");
wx.hideShareMenu();
},
shareAppMessageScn: function(e, t) {
console.log("[WXHelper.shareAppMessageScn]");
wx.updateShareMenu({
withShareTicket: t,
success: function() {
wx.shareAppMessage({
title: e,
imageUrl: canvas.toTempFilePathSync({
destWidth: 1280,
destHeight: 720
}),
success: function(e) {
console.log("[wx.shareAppMessage] success.");
console.log(e);
},
fail: function(e) {
console.log("[wx.shareAppMessage] fail.");
console.log(e);
},
complete: function(e) {
console.log("[wx.shareAppMessage] complete.");
console.log(e);
}
});
}
});
},
shareAppMessage: function(e, t) {
console.log("[WXHelper.shareAppMessage]");
wx.shareAppMessage({
title: e,
imageUrl: t,
success: function(e) {
console.log("[wx.shareAppMessage] success.");
console.log(e);
},
fail: function(e) {
console.log("[wx.shareAppMessage] fail.");
console.log(e);
},
complete: function(e) {
console.log("[wx.shareAppMessage] complete.");
console.log(e);
}
});
},
shareAppMessageQuery: function(e, t, n, o, a, c) {
var i = new PacketWriter();
i.writeid(cc.vv.packid.PACKETID_249);
i.writeu2(c);
i.writeu1(1);
cc.vv.socketMgr.bufferPack(i.getdata());
console.log("[WXHelper.shareAppMessageQuery]");
console.log(n);
wx.shareAppMessage({
title: e,
query: n,
imageUrl: t,
success: function(e) {
console.log(e);
console.log("[wx.shareAppMessage] success.");
var t = new PacketWriter();
t.writeid(cc.vv.packid.PACKETID_249);
t.writeu2(c);
t.writeu1(3);
cc.vv.socketMgr.bufferPack(t.getdata());
"function" == typeof o && o(e);
},
fail: function(e) {
console.log(e);
console.log("[wx.shareAppMessage] fail.");
"function" == typeof a && a();
},
complete: function(e) {
console.log("[wx.shareAppMessage] complete.");
console.log(e);
}
});
},
login: function() {
console.log("[WXHelper.login]");
this._authorize();
},
_login: function(e) {
if ("function" == typeof e) var t = e;
console.log("[WXHelper._login]");
wx.getSetting({
success: function(e) {
if (e.authSetting["scope.userInfo"]) {
console.log("authorized.");
t();
} else {
var n = 0, o = 0;
wx.getSystemInfo({
success: function(e) {
n = e.screenWidth;
o = e.screenHeight;
},
fail: function() {
console.log("[wx.getSystemInfo] fail.");
}
});
var a = cc.url.raw(cc.GameTexture.wxmingamelogin), c = wx.createUserInfoButton({
type: "image",
image: a,
text: "登陆游戏",
style: {
left: n / 2 - cc.GameTexture.wxmingamelogin_width / 2,
top: o / 2 - cc.GameTexture.wxmingamelogin_height / 2,
width: cc.GameTexture.wxmingamelogin_width,
height: cc.GameTexture.wxmingamelogin_height,
borderRadius: 4
}
});
c.onTap(function() {
wx.authorize({
scope: "scope.userInfo",
success: function() {
console.log("[wx.authorize] success.");
c.destroy();
t();
},
fail: function() {
console.log("[wx.authorize] fail.");
},
complete: function() {
console.log("[wx.authorize] complete.");
}
});
});
}
},
fail: function() {
console.log("[wx.getSetting] fail.");
},
complete: function() {
console.log("[wx.getSetting] complete.");
}
});
},
loadLocalSessionID: function() {
console.log("[WXHelper.loadLocalSessionID]");
if (null == this.sessionID) {
var e = wx.getStorageSync("SESSION_ID");
if (e) {
this.sessionID = e;
console.log("[WXHelper.loadLocalSessionID] " + this.sessionID);
} else console.log("[WXHelper.loadLocalSessionID] get sessionid fail.");
}
},
_getUserInfo: function(e) {
var t = this;
console.log("[WXHelper._getUserInfo]");
wx.getUserInfo({
withCredentials: !0,
success: function(n) {
t.userInfoObj = n;
console.log("[wx.getUserInfo success]");
"function" == typeof e && e();
}
});
},
downloadAllResources: function(e, t) {
var n = cc.GameConst.URL_RES_INCLUDE_FILE;
this.downloadTotalCountArr = [];
this.downloadCompleteCountArr = [];
this.downloadProgress = 0;
for (var o = this, a = 0; a < n.length; a++) {
o.downloadTotalCountArr[a] = 0;
o.downloadCompleteCountArr[a] = 0;
(function(a) {
cc.loader.loadResDir(n[a], function(n, c) {
o.dealDownloadProgress(o, a, n, c);
t && t(e, o.downloadProgress);
}, function(e) {
e ? cc.error(e) : console.log("[cc.loader.loadResDir] complete..." + n[a]);
});
})(a);
}
},
dealDownloadProgress: function(e, t, n, o) {
e.downloadTotalCountArr[t] = o;
e.downloadCompleteCountArr[t] = n;
if (cc.GameConst.URL_RES_INCLUDE_FILE.length == e.downloadTotalCountArr.length) {
var a = e.getProgress(e.downloadCompleteCountArr), c = e.getProgress(e.downloadTotalCountArr);
this.downloadProgress = Math.floor(a / c * 100) >= this.downloadProgress ? Math.floor(a / c * 100) : this.downloadProgress;
}
},
getProgress: function(e) {
for (var t = 0, n = 0; n < e.length; n++) t += e[n];
return t;
},
setShareCanvasGameAwardData: function(e, t, n, o) {
wx.postMessage({
command: e,
nickName: cc.vv.utils.getSubstringDataByLength(cc.vv.myself.playerName),
headImgUrl: cc.vv.myself.playerIcon,
masterPoint: t,
bonus: n,
totalBonus: o
});
},
getCustomShareCanvasToShare: function(e, t, n) {
sharedCanvas.toTempFilePath({
x: 0,
y: 0,
width: sharedCanvas.width,
height: sharedCanvas.height,
destWidth: 1e3,
destHeight: 800,
fileType: "png",
quality: -1,
success: function(o) {
var a = o.tempFilePath;
wx.updateShareMenu({
withShareTicket: !1,
success: function() {
var o = new PacketWriter();
o.writeid(cc.vv.packid.PACKETID_249);
o.writeu2(n);
o.writeu1(1);
cc.vv.socketMgr.bufferPack(o.getdata());
wx.shareAppMessage({
title: e,
imageUrl: a,
query: t,
success: function() {
var e = new PacketWriter();
e.writeid(cc.vv.packid.PACKETID_249);
e.writeu2(n);
e.writeu1(3);
cc.vv.socketMgr.bufferPack(e.getdata());
}
});
}
});
}
});
},
getScreenCanvasToLocalPath: function(e, t) {
wx.saveImageToPhotosAlbum ? wx.getSetting({
success: function(n) {
console.log("getSetting: success");
if (n.authSetting["scope.writePhotosAlbum"]) {
console.log("1-已经授权《保存图片》权限");
var o = canvas.toTempFilePathSync({
x: 0,
y: 0,
width: canvas.width,
height: canvas.height,
destWidth: canvas.width,
destHeight: canvas.height,
fileType: "png",
quality: -1
});
wx.saveImageToPhotosAlbum({
filePath: o,
success: function() {
null != e && e();
}
});
} else {
console.log("1-没有授权《保存图片》权限");
wx.authorize({
scope: "scope.writePhotosAlbum",
success: function() {
console.log("2-授权《保存图片》权限成功");
var t = canvas.toTempFilePathSync({
x: 0,
y: 0,
width: canvas.width,
height: canvas.height,
destWidth: 1280,
destHeight: 720,
fileType: "png",
quality: -1
});
wx.saveImageToPhotosAlbum({
filePath: t,
success: function() {
null != e && e();
}
});
},
fail: function() {
console.log("用户拒绝了授权");
null != t && t();
}
});
}
}
}) : wx.showModal({
title: "提示",
content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
});
},
downloadSharedCanvasResources: function() {
wx.getFileSystemManager();
wx.downloadFile({
url: wxDownloader.REMOTE_SERVER_ROOT + "fzmj_match_sharedCanvas_res/share_bg.png",
success: function(e) {
200 === e.statusCode && wx.postMessage({
command: "bgRes",
path: e.tempFilePath
});
}
});
wx.downloadFile({
url: wxDownloader.REMOTE_SERVER_ROOT + "fzmj_match_sharedCanvas_res/yuan.png",
success: function(e) {
200 === e.statusCode && wx.postMessage({
command: "yuanRes",
path: e.tempFilePath
});
}
});
},
getFriendRank: function() {
wx.postMessage({
command: "friendRank",
keyData: [ this.weChatKey[0], this.weChatKey[1] ]
});
},
getAnswerRank: function() {
wx.postMessage({
command: "getAnswerChange",
keyData: this.weChatKey[2],
myOpenId: this.openId,
myName: cc.vv.myself.playerName,
myHeadUrl: cc.vv.myself.playerIcon,
myTime: cc.vv.myself.answerCounTime
});
},
friendRankPageActiveChange: function(e) {
wx.postMessage({
command: "pageChange",
pIndex: e,
myOpenId: this.openId
});
},
setRankHeight: function(e) {
wx.postMessage({
command: "RankHeight",
keyData: this.RankHeight[e]
});
},
setConfigFriendRankData: function(e, t, n, o) {
wx.postMessage({
command: "setRankData",
keyData: [ {
key: e[0],
data: t
}, {
key: e[1],
data: n
}, {
key: e[2],
data: o
} ]
});
},
setMoveTouchDeltaY: function(e) {
wx.postMessage({
command: "moveTouch",
y: e
});
},
setMoveTouchOff: function() {
wx.postMessage({
command: "moveTouchOff"
});
},
setSharedCanvasChildrenActive: function(e) {
wx.postMessage({
command: "shareCanvasChange",
pIndex: e
});
},
setSharedCanvasSize: function(e, t) {
sharedCanvas.width = e;
sharedCanvas.height = t;
},
setSharedCanvasDesignResolution: function(e, t) {
wx.postMessage({
command: "designResolution",
designWidth: e,
designHeight: t
});
},
getSurpassFriendData: function() {
wx.postMessage({
command: "surpassFriendRank",
keyData: this.weChatKey[0],
myOpenId: this.openId
});
},
initLoadGroupRankVieW: function() {
wx.postMessage({
command: "groupRank",
shareTicket: this.shareTicket,
keyData: this.weChatKey,
myOpenId: this.openId,
initGroupIndex: 0
});
this.setSharedCanvasSize(this._groupRankCanvasWidth, this._groupRankCanvasHeight);
this.setSharedCanvasDesignResolution(this._groupRankCanvasWidth, this._groupRankCanvasHeight);
this.setSharedCanvasChildrenActive(1);
},
keepScreenOn: function() {
wx.setKeepScreenOn && wx.setKeepScreenOn({
keepScreenOn: !0,
success: function() {
console.log("[wx.setKeepScreenOn] success.");
},
fail: function() {
console.log("[wx.setKeepScreenOn] fail.");
},
complete: function() {
console.log("[wx.setKeepScreenOn] complete.");
}
});
}
};
t.exports = n;
cc.WXHelper = n;
cc._RF.pop();
}, {} ],
customSprite: [ function(e, t) {
"use strict";
cc._RF.push(t, "6bba6f1ujVIM4SITnpLJH+A", "customSprite");
var n = cc.Enum({
Null: 0,
Bg_1: 1,
Bg_2: 2
});
cc.Enum({
Bg: 0,
Disperse: 1
}), cc.Class({
extends: cc.Sprite,
editor: {
disallowMultiple: !0,
executeInEditMode: !0,
menu: "自定义组件/自定义精灵组件"
},
properties: {
bgTexture: {
default: n.Null,
type: n,
displayName: "图片精灵背景贴图枚举",
notify: function() {
this.onLoadTexture2DToSprite();
}
},
fileName: {
default: "bg",
displayName: "散图文件夹"
},
disperseName: {
default: "null",
displayName: "搜索图片",
multiline: !1,
notify: function() {
this.onSpriteNameToAtlasEvent();
}
},
disperseIndex: {
default: 0,
type: cc.Integer,
displayName: "散图序号",
notify: function() {
this.onSpriteFrameIndexToAtlasEvent();
}
},
disperse: {
default: !0,
displayName: "图集模式"
},
_oldDefaultTexture2D: null,
_oldSpriteFrame: null
},
_applyAtlas: !1,
onLoadTexture2DToSprite: function() {
var e = this;
this.textureUrl = cc.url.raw("res/texture/" + this.fileName + "/" + (this.fileName + this.bgTexture) + ".png");
this.bgTexture !== n.Null ? cc.loader.load(this.textureUrl, function(t, n) {
e.spriteFrame = null;
var o = new cc.SpriteFrame(n);
if (e._oldSpriteFrame !== o) {
e.spriteFrame = o;
e._oldSpriteFrame = e.spriteFrame;
}
}) : this.spriteFrame = null;
},
onSpriteFrameIndexToAtlasEvent: function() {
-1 !== this.disperseIndex && (this.disperse && this._atlas ? this.disperseIndex >= 0 && this.disperseIndex < this._atlas.getSpriteFrames().length ? this.spriteFrame = this._atlas.getSpriteFrames()[this.disperseIndex] : this.disperseIndex < this._atlas.getSpriteFrames().length / 2 ? this.disperseIndex = 0 : this.disperseIndex = this._atlas.getSpriteFrames().length - 1 : cc.error("请将图集文件拖入Atlas框中"));
},
onSpriteNameToAtlasEvent: function() {
if ("" !== this.disperseName) if (this.disperse && this._atlas) for (var e = 0; e < this._atlas.getSpriteFrames().length; e++) this._atlas.getSpriteFrames()[e].name === this.disperseName && (this.spriteFrame = this._atlas.getSpriteFrames()[e]); else cc.error("请将图集文件拖入Atlas框中");
}
});
cc._RF.pop();
}, {} ],
use_reversed_rotateTo: [ function(e, t) {
"use strict";
cc._RF.push(t, "8fff2nib3hCXIZZpnhi7k/c", "use_reversed_rotateTo");
cc.RotateTo._reverse = !0;
cc._RF.pop();
}, {} ]
}, {}, [ "use_reversed_rotateTo", "GameConst", "GameEnum", "GameErrorCode", "GameEvent", "GameLanguage", "GameNetMgr", "GameResource", "GameTexture", "GuideManage", "Utils", "AnimationCtr", "ColliderListener", "CountDown", "Hall", "InputNumber", "AppStart", "GameConfig", "AudioMgr", "customSprite", "DLocal", "DUser", "WXHelper" ]);